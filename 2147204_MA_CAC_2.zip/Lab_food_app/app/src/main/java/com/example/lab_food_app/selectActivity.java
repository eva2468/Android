package com.example.lab_food_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class selectActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);

    }
    public void click_img(View view)
    {
        Toast.makeText(this, "Item added to cart", Toast.LENGTH_SHORT).show();
    }
    public void click_cart(View view)
    {
        Intent cart= new Intent(this,cartActivity.class);
        startActivity(cart);
    }
}