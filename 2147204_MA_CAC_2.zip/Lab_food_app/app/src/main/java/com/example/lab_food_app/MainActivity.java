package com.example.lab_food_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    EditText uname,pass;
    String username,password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        uname=(EditText)findViewById(R.id.uname);
        pass=(EditText) findViewById(R.id.pass);



    }
    public void click(View view)
    {
        Intent callIntent = new Intent(this, MainActivity2.class);
        username=uname.getText().toString();
        if( uname.getText().toString().equals("admin") &&  pass.getText().toString().equals("admin"))
        {
            callIntent.putExtra("username",username);
            startActivity(callIntent);
        }
        else
        {
            Toast.makeText(this, "WRONG USERNAME OR PASSWORD", Toast.LENGTH_SHORT).show();
        }

    }
    public void social_google(View view)
    {

        String url = "https://accounts.google.com/signin/v2/identifier?flowName=GlifWebSignIn&flowEntry=ServiceLogin";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }
    public void social_facebook(View view)
    {

        String url = "https://www.facebook.com/login/?privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNjU5OTgwNzg2LCJjYWxsc2l0ZV9pZCI6MjY5NTQ4NDUzMDcyMDk1MX0%3D";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }
    public void social_twiter(View view)
    {

        String url = "https://twitter.com/i/flow/login?lang=en";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }
}