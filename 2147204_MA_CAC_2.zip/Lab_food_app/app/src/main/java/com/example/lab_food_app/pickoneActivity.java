package com.example.lab_food_app;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class pickoneActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    FloatingActionButton fab_1,fab_2;
    TextView text_1;
    Boolean isAllFabsVisible;
    ConstraintLayout mainlayout;
    AlertDialog.Builder builder;
    Button button;
    EditText name,addr,pincode,landmark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pickone);
        //setSupportActionBar(toolbar);
        name=findViewById(R.id.name);
        fab_1 = findViewById(R.id.fab_1);
        button=findViewById(R.id.popup);
        mainlayout = findViewById(R.id.layout_main);
        builder = new AlertDialog.Builder(this);

        // FAB button
        fab_2 = findViewById(R.id.add_alarm_fab);


        // Also register the action name text, of all the FABs.
        text_1 = findViewById(R.id.text_fab_2);


        // Now set all the FABs and all the action name texts as GONE
        fab_2.setVisibility(View.GONE);
        text_1.setVisibility(View.GONE);


        // make the boolean variable as false, as all the
        // action name texts and all the sub FABs are invisible
        isAllFabsVisible = false;

        // We will make all the FABs and action name texts
        // visible only when Parent FAB button is clicked So
        // we have to handle the Parent FAB button first, by
        // using setOnClickListener you can see below
        fab_1.setOnClickListener(view -> {
            if (!isAllFabsVisible) {
                // when isAllFabsVisible becomes true make all
                // the action name texts and FABs VISIBLE
                fab_2.show();
                text_1.setVisibility(View.VISIBLE);


                // make the boolean variable true as we
                // have set the sub FABs visibility to GONE
                isAllFabsVisible = true;
            } else {
                // when isAllFabsVisible becomes true make
                // all the action name texts and FABs GONE.
                fab_2.hide();
                text_1.setVisibility(View.GONE);


                // make the boolean variable false as we
                // have set the sub FABs visibility to GONE
                isAllFabsVisible = false;
            }
        });
        // Spinner element
        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        // Spinner click listener
        spinner.setOnItemSelectedListener(this);

        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("9 am to 5 pm");
        categories.add("Anytime");

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Initializing the popup menu and giving the reference as current context
                PopupMenu popupMenu = new PopupMenu(pickoneActivity.this, button);

                // Inflating popup menu from popup_menu.xml file
                popupMenu.getMenuInflater().inflate(R.menu.popup, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        // Toast message on menu item clicked
                        Toast.makeText(pickoneActivity.this, "You Clicked " + menuItem.getTitle(), Toast.LENGTH_SHORT).show();
                        return true;
                    }
                });
                // Showing the popup menu
                popupMenu.show();
            }
        });
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(position).toString();



    }
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }



    public void click(View view) {
        Intent i = new Intent(this, paymentActivity.class);
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage("hello") .setTitle("Confirm");
        if (TextUtils.isEmpty(name.getText().toString()))
        {
            Toast.makeText(this, "Enter the name", Toast.LENGTH_SHORT).show();
        }
       /* if(TextUtils.isEmpty(addr.getText().toString())) {
            Toast.makeText(this, "Enter Delivery Address", Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(pincode.getText().toString())) {
            Toast.makeText(this, "Enter The Pincode", Toast.LENGTH_SHORT).show();
        }*/
        else {


            //Setting message manually and performing action on button click
            builder.setMessage("Do you want to proceed to payment ?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            finish();
                            startActivity(i);
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            //  Action for 'NO' Button
                            dialog.cancel();
                        }
                    });
            //Creating dialog box
            AlertDialog alert = builder.create();
            //Setting the title manually
            alert.setTitle("Confirm");
            alert.show();

        }

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

}