package com.example.lab_food_app;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityFragment extends AppCompatActivity {
    Button fragment1,fragment2,fragment3,fragment4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment2);
        fragment1 = (Button) findViewById(R.id.button);


        listener();

    }
    public void  home(View view)
    {
        Intent home=new Intent(this,reviewActivity.class);
        startActivity(home);

    }
    public void listener() {
        fragment1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction f1 = getSupportFragmentManager().beginTransaction();
                fragment1 ff1 = new fragment1();
                f1.replace(R.id.fragment_container, ff1);
                f1.commit();
            }
        });



    }




}