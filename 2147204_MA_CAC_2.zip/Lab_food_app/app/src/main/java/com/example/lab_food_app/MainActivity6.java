package com.example.lab_food_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;


public class MainActivity6 extends AppCompatActivity {
    public static final String MES="MY Message";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(MES, "onCreate called");
        Toast.makeText(this, "onCreate() called", Toast.LENGTH_SHORT).show();
        setContentView(R.layout.activity_main6);
    }
    public void onClickButton(View v) {
        Intent i = new Intent(this, MainActivity7.class);
        startActivity(i);

    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.i(MES, "onStart called");
        Toast.makeText(getApplicationContext(), "onStart called", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(MES, "onResume called");
        Toast.makeText(getApplicationContext(), "onResume called", Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.i(MES, "onPause called");
        Toast.makeText(getApplicationContext(), "onPause called", Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.i(MES, "onStop called");
        Toast.makeText(getApplicationContext(), "onStop called", Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(MES, "onDestroy called");
        Toast.makeText(getApplicationContext(), "onDestroy called", Toast.LENGTH_LONG).show();

    }

}
