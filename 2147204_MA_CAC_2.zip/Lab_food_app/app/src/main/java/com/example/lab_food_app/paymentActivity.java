package com.example.lab_food_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

public class paymentActivity extends AppCompatActivity {
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        WebView webView = findViewById(R.id.web);
        b=findViewById(R.id.pay);
        registerForContextMenu(b);


        // loading http://www.google.com url in the WebView.
        webView.loadUrl("https://classroom.google.com/c/NDk3MDM3Nzk3NzIx/a/NTQ2MzQzNDUyMzk4/details");

        // this will enable the javascript.
        webView.getSettings().setJavaScriptEnabled(true);

        // WebViewClient allows you to handle
        // onPageFinished and override Url loading.
        webView.setWebViewClient(new WebViewClient());
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Choose an option");
        getMenuInflater().inflate(R.menu.context_menu, menu);
    }
    public void click( View v)
    {
        //Toast toast= Toast.makeText("Payment successful",this).show();
        Toast.makeText(this, "Payment succesfull", Toast.LENGTH_SHORT).show();
//        Intent i=new Intent(this,reviewActivity.class);
        Intent i= new Intent(this,ActivityFragment.class);
        startActivity(i);
    }


}