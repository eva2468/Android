package com.example.lab_food_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RatingBar;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class reviewActivity extends AppCompatActivity {


    RatingBar rat;
    ConstraintLayout layout;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        Intent home= new Intent(this,MainActivity2.class);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);


        rat = (RatingBar) findViewById(R.id.rat);
        layout = findViewById(R.id.ratlay);

        rat.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            // Called when the user swipes the RatingBar
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

                Snackbar snackbar
                        = Snackbar
                        .make(  layout
                                ,
                                String.valueOf(rat.getRating()),
                                Snackbar.LENGTH_LONG)
                        .setAction(
                                "Okay",


                                new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view)
                                    {
                                        Toast
                                                .makeText(
                                                        reviewActivity.this,
                                                        "Ok Clicked",
                                                        Toast.LENGTH_SHORT)
                                                .show();
                                        startActivity(home);


                                    }
                                });

                snackbar.show();
            }
        });



    }
}